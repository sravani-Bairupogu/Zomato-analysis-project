create database Zomato2;
use zomato2;
create table salespeople (snum int,sname varchar(50),city varchar(50),comm float);
insert into salespeople(snum,sname,city,comm)
values (1001,"peel","London",0.12),
       (1002,"seeres","san jose",0.13),
       (1003,"Axeleord","New york",0.10),
       (1004,"Motika","London",0.11),
       (1007,"Rafkin","Barcelona",0.15);
       
select * from salespeople;

#---- 2 Q/A 

create table cust (cnum int ,cname char(30),city char(30),rating int,snum int);
insert into cust(cnum ,cname ,city ,rating ,snum )
values (2001,"Hoffman","London",100,1001),
       (2002,"Giovanne","London",100,1001),
       (2003,"Liu","San jose",300,1002),
       (2004,"Grass","Berlin",100,1002),
       (2006,"Clemens","London",300,1007),
       (2001,"pereria","London",100,1004),
       (2001,"James","London",200,1007);
select * from cust;


#---- 3rd Q/A 
create table orders(onum int ,amt float ,odate date,cnum int ,snum int);
insert into orders(onum ,amt ,odate ,cnum ,snum )
values (3001,18.69,'1994-10-03',2008,1007),
	   (3002,1900.10,'1994-10-03',2007,1004), 
       (3003,767.19,'1994-10-03',2001,1001),
       (3005,5160.45,'1994-10-03',2003,1002),
       (3006,1098.16,'1994-10-04',2008,1007),
       (3007,75.75,'1994-10-05',2004,1002),
       (3008,4723.00,'1994-10-05',2006,1001),
       (3009,1713.23,'1994-10-04',2002,1003),
       (3010,1309.95,'1994-10-04',2004,1002),
       (3011,9891.88,'1994-10-06',2006,1001);
select * from orders;

#----4th Q/A 
select  sname, cname , salespeople.city
from salespeople
join cust
on salespeople.snum = cust.snum;

#-- 5th Q/A 
select  sname, cname 
from salespeople
join cust
on salespeople.snum = cust.snum;

#-- 6th Q/A 
select onum ,cust.cname ,cust.city ,salespeople.sname,salespeople.city 
from cust
join orders 
on  orders.cnum = cust.cnum
join salespeople 
on orders.snum = cust.snum
where 
cust.city <> salespeople.city;

#-- 7th Q/A 
select onum as "order number " ,cname as "Customer name "
from orders 
join cust
on orders.cnum = cust.cnum;

#-- 8th Q/A 
select 
c1.cname  as "customer 1 ",
c2.cname as "customer 2 ",
c1.rating as "Rating " 
from cust c1
join cust c2
on  c1.rating = c2.rating and c1.cnum < c2.cnum ;

#--- 9th Q/A 
select 
c1.cname  as "customer 1 ",
c2.cname as "customer 2 ",
s.sname as "salesperson"
from cust c1
join cust c2
on  c1.snum = c2.snum and c1.cnum < c2.cnum 
join salespeople s 
on c1.snum  = s.snum;

#--- 10th Q/A 
select 
s1.sname as "salespeople 1",
s2.sname as "salespeople 2",
s1. city as "Same city"
from salespeople s1 
join salespeople s2 
on s1.city= s2.city  and s1.snum < s2.snum;

#-- 11th Q/A 
select o.onum as orders, o.cnum as cust_num, c.cname as customer,s.sname as salespersons 
from salespeople s join cust c on s.snum = c.snum join orders o on o.snum = c.snum
 where o.cnum like '2008%' group by o.cnum, o.onum, s.sname, c.cname order by cust_num;

#-- 12th Q/A 
select 
onum , odate  
from orders 
where 
amt > (select avg(amt ) from orders 
		where odate = '1994-10-04');

#-- 13th Q/A 
select onum as "orders " ,sname as "salespeople",city from orders
inner join salespeople
on orders.snum = salespeople.snum 
where salespeople.city = "london";

#-- 14th Q/A 
 select
c.cnum AS "Customer Number", 
c.snum AS "Salesperson Number"
from Cust c
where c.cnum = c.snum + 1000;

#-- 15th Q/A 

select count(cname)as customer , rating from cust where rating =300;

#---16th Q/A
select s.snum, s.sname, 
count(c.cnum) as "Customer Count"
from Salespeople s
join Cust c
 on s.snum = c.snum
group by 
s.snum, 
s.sname
having count(c.cnum) > 1;





