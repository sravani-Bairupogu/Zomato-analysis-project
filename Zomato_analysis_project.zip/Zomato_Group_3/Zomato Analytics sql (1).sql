use zomato;
create table Employee ( empno int not null primary key , ename varchar(100) default 'clerk' ,job varchar(100)default 'clerk', mgr int , 
					   hiredate date ,sal float check (sal>0), comm float, deptno int, CONSTRAINT fk_dept FOREIGN KEY (deptno) references dept(deptno));

select * from Employee;
insert into Employee ( empno,ename ,job,mgr,hiredate ,sal, comm , deptno)
VALUES  (7369,"SMITH","CLERK",7902,'1890-12-17',800.00,Null,20),
		(7499 ,"ALLEN","SALESMAN",7698,'1981-02-20',1600.00,300.00,30),
        (7521 ,"WARD","SALESMAN",7698,'1981-02-22',1250.00,500.00,30),
        (7566 ,"JONES","MANAGER",7839,'1981-04-02',2975.00,NULL,20),
        (7654 ,"MARTIN","SALESMAN",7698,'1981-09-28',1250.00,1400.00,30),
        (7698 ,"BLAKE","MANAGER",7839,'1981-05-01',2850.00,NULL,30),
        (7782 ,"CLARK","MANAGER",7839,'1981-06-09',2450.00,NULL,10),
        (7788 ,"SCOTT","ANALYST",7566,'1987-04-19',3000.00,NULL,20),
        (7839 ,"KING","PRESIDENT",NULL,'1981-11-17',5000.00,NULL,10),
        (7844 ,"TURNER","SALESMAN",7698,'1981-09-08',1500.00,0.00,30),
        (7876 ,"ADAMS","CLERK",7788,'1987-05-23',1100.00,NULL,20),
        (7900 ,"JAMES","CLERK",7698,'1981-12-03',950.00,NULL,30),
        (7902 ,"FORD","ANALYST",7566,'1981-12-03',3000.00,NULL,20),
        (7934 ,"MILLER","CLERK",7782,'1982-01-23',1300.00,NULL,10);
      
        
      
create table dept (deptno int primary key, dname varchar(100),loc varchar(30));
select * from dept;
insert into dept (deptno , dname ,loc )
values (10, "OPERATIONS ", "BOSTON"),
       (20,"RESEARCH","DALLAS"),
       (30,"SALES","CHICAGO"),
       (40,"ACCOUNTING","NEW YORK");
       
       
#----- 3rd Q/A 
select ename , sal from employee 
where sal > 1000 ;

#---- 4th Q/A 
select  empno,ename ,job,mgr,hiredate ,sal, comm , deptno from employee
where hiredate < '1981-10-01';

#---- 5th Q/A 
select ename from employee
where ename like '_I%';

#--- 6th Q/A 
select ename as "employeename",
       sal as "salary",
       (sal*0.40) as "allowances",
       (sal*0.10) as "P.F.",
       (sal+(sal*0.40)-(sal*0.10)) as "Net salary"
       from employee;
       
#--- 7th Q/A 
select ename as "employeename",
	   job  as "designation" from employee
  where  mgr is null;

#--- 8th Q/A 
select empno,ename,sal from employee
order by empno ,ename,sal  asc;

#-- 9th Q/A 
select count(distinct job ) as "Jobs available "
from employee;

#-- 10th Q/A
 select SUM(sal) AS "Total Payable Salary"
from Employee
where  job = 'Salesman';

#-- 11th Q/A
select  deptno,  job, avg(sal) as "Monthly salary"
from employee
group by job ,deptno
order by 1,2 asc;

#-- 12th Q/A
select ename as EMPNAME ,sal as SALARY , dname as DEPTNAME 
from employee 
join dept 
on employee.deptno = dept.deptno;

#-- 13th Q/A
create table job_Grades (grade char(30),lowest_sal int ,highest_sal  int);
insert into job_Grades (grade,lowest_sal,highest_sal)
values ("A",0,999),
       ("B",1000,1999),
       ("C",2000,2999),
       ("D",3000,3999),
       ("E",4000,5000);
select * from job_Grades;

#-- 14th Q/A
select ename as "firstname" , sal as "salary",
case  
when  sal<999 then 'Grade A'
when sal>=1000 and sal<2000 then 'Grade B'
when sal>=2000 and sal<3000 then 'Grade C'
when sal>=3000 and sal<4000 then 'Grade D'
else  'Grade E'
end as "corresponding grade"
from employee ;

#--- 15th Q/A 
select e.ename as  "Emp", 
       m.ename as "Mgr"
from employee e
left join  employee m
on e.mgr = m.empno;

#--- 16th Q/A 
select ename as "Empname ",sum(sal+coalesce(comm,0)) as "Total salary "   #----coalesce will help in replacing null values in operations
from employee
group by sal,comm , ename;

#--- 17th Q/A 
select ename as Empname , sal as "salary" from employee
where  MOD(empno,2)=1;

#--- 18th Q/A 
select ename as Empname ,
RANK() over (order by sal desc) as "sal in organisation",
RANK() over (partition by deptno order by sal desc) as "sal in department"
from employee;

#--- 19th Q/A 
select ename as Empnames , sal as salary from employee
order by sal desc
limit 3;

#--- 20th Q/A 
select ename as Empname ,sal as salary ,dname
from employee
join 
dept on employee.deptno = dept.deptno
order by sal desc;

